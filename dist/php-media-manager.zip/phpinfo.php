<?php
// Display PHP information
phpinfo();
?>