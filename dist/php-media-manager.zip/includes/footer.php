<?php
/**
 * Footer template for Media Manager
 * Contains closing body elements and JavaScript includes
 */
?>
    </div><!-- /.main-container -->
    
    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom JavaScript -->
    <script src="js/script.js"></script>
</body>
</html>
